import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminShowDogComponent } from './admin-show-dog/admin-show-dog/admin-show-dog.component';
import { AdminShowDogsComponent } from './admin-show-dogs/admin-show-dogs/admin-show-dogs.component';
import { AddDogComponent } from './add-dog/add-dog.component';
import { LoginComponent } from './login/login.component';
import { AuthService } from './service/authentication.service';
import { SignupComponent } from './signup/signup/signup.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'dogs', component: AdminShowDogsComponent },
  { path: 'dog/:id', component: AdminShowDogComponent },
  { path: 'add', component: AddDogComponent, canActivate: [AuthService]},
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
