import { Component } from '@angular/core';
import { DogModel } from 'src/app/model/dog.model';
import { Dogservice } from 'src/app/service/dog.service';

@Component({
  selector: 'app-admin-show-dogs',
  templateUrl: './admin-show-dogs.component.html',
  styleUrls: ['./admin-show-dogs.component.css']
})
export class AdminShowDogsComponent {
  dogs: DogModel[] = []

  userType: string;

  constructor(private dogService: Dogservice) {
    this.userType = '';
   }
  ngOnInit(): void {
    this.userType = localStorage.getItem('userType') as string;
    this.dogService.getAllDogs().subscribe((data: DogModel[]) => { this.dogs = data });
  }

  delete(dog: DogModel): void {
    this.dogs = this.dogs.filter(x => x !== dog);
    this.dogService.deleteDog(dog.id).subscribe();
  }


}
