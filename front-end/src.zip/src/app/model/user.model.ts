export class User {

  id: number = 0;

  username: string;

  password: string;

  usertype: string;

  constructor(username: string, password: string, usertype: string) {
    this.username = username;
    this.password = password;
    this.usertype = usertype;
  }
}
