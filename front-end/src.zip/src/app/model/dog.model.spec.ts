import { DogModel } from './dog.model';

describe('DogModel', () => {
  it('should create an instance', () => {
    expect(new DogModel()).toBeTruthy();
  });
});
