export class DogModel {
    id: number = 0
    name: string = ''
    breed: string = ''
    age: number = 0
    status: string = ''
    imgURL: string = ''
    
}
