import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:18080/api'; // Replace with your backend API URL

  constructor(private http: HttpClient) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const userType = localStorage.getItem('userType')
    const userId = localStorage.getItem('userId')
    if (userId === null || userType !== 'admin') {
      return false;
    }
    return true;
  }

  login(username: string, password: string, userType: string) {
    const user = new User(username, password, userType)
    return this.http.post(this.apiUrl + '/login', user);
  }
}
