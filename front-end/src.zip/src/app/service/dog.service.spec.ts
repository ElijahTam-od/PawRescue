import { DogService } from './dog.service';

describe('DogService', () => {
  it('should create an instance', () => {
    expect(new DogService()).toBeTruthy();
  });
});
