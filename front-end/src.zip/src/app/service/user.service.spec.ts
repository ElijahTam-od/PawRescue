import { UserService } from './user.service';

describe('UserService', () => {
  it('should create an instance', () => {
    expect(new UserService()).toBeTruthy();
  });
});
